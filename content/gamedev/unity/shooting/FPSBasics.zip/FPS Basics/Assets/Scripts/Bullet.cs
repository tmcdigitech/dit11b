using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
	public float timer = 1f;

	void Update()
	{
		// Using a timer
		//timer -= Time.deltaTime;

		//if (timer <= 0)
		//{
		//	Destroy(gameObject);
		//}
	}

	// Destroy when nolonger visible
	private void OnBecameInvisible()
	{
		Destroy(gameObject);
	}
	// Destroy on collision
	private void OnCollisionEnter(Collision collision)
	{
		Destroy(gameObject);
	}
}